package com.slamtec.slamware.uicommander.event;


public class ConnectionLostEvent {
    // intentionally empty
}
