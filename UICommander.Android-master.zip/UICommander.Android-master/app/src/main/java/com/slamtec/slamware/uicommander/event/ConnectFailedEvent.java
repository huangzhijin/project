package com.slamtec.slamware.uicommander.event;


public class ConnectFailedEvent {
    // intentionally empty
}
