package com.slamtec.slamware.uicommander.event;


public class ConnectedEvent {
    // intentionally empty
}
